# Slider
The slider with autoplay and manual steering created with vanilla JS.

Github-pages: https://karolkkas.github.io/Slider/
